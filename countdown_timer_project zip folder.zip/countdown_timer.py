import time

# Define a function that performs the countdown
def countdown(t):
    # Continue looping while t (time in seconds) is greater than 0
    while t:
        # Convert total seconds into minutes and seconds using divmod
        mins, secs = divmod(t, 60)
        
        # Format the time as MM:SS (e.g., 02:15)
        timer = '{:02d}:{:02d}'.format(mins, secs)
        
        # Print the timer value and overwrite it each second using carriage return (\r)
        print(timer, end="\r")
        
        # Pause the loop for 1 second
        time.sleep(1)
        
        # Decrease the countdown by 1 second
        t -= 1

    # Once the loop ends, print that the countdown has completed
    print('Timer completed!')

# Create an infinite loop to repeatedly ask the user for input
while True:
    # Ask the user to input the countdown time in seconds
    t = input("Enter the time in seconds: ")
    
    # Check if the input consists only of digits (i.e., a valid positive integer)
    if t.isdigit():
        # Convert the input string to an integer and start the countdown
        countdown(int(t))
    else:
        # If the input is not a valid number, print an error message
        print("Invalid input. Please enter a number.")