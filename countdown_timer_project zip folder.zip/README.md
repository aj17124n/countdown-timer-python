# Countdown Timer Python Project

## Description
This project is a simple terminal-based countdown timer built with Python. It takes the user’s input in seconds and performs a real-time countdown displayed in MM:SS format. The project reinforces foundational Python skills including time manipulation, loops, input validation, and terminal output formatting.

## How to Run the Project
1. Make sure Python is installed on your system.
2. Save the script as `countdown_timer.py`.
3. Open a terminal or command prompt.
4. Run the file with:  
   ```bash
   python countdown_timer.py
   ```
5. Enter the time in seconds when prompted.

## Tutorial/Material Used
- Python official documentation: [https://docs.python.org/3/library/time.html](https://docs.python.org/3/library/time.html)
- Basic Python syntax knowledge from [W3Schools](https://www.w3schools.com/python/)

## Customizations Made
- Added MM:SS formatting using `divmod()`
- Real-time output updates using `\r` carriage return
- User input validation using `.isdigit()`
- Continuous loop for repeated countdowns

## What I Learned
- How to use the `time` module in Python
- How to create a formatted output for the terminal
- How to build interactive programs that take user input
- How to validate input and handle invalid entries
- Basics of sharing a Python project on GitHub

## Author
Algassimu Jalloh  
Master’s in Information Systems, Pace University